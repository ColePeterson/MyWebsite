

const bufferSeconds = 1;

var audioCtx = new (window.AudioContext || window.webkitAudioContext)();
var bLength = audioCtx.sampleRate * bufferSeconds;

var bufferA = audioCtx.createBuffer(2, bLength, audioCtx.sampleRate);
var bufferB = audioCtx.createBuffer(2, bLength, audioCtx.sampleRate);

document.getElementById("bSize").innerHTML = "Buffer Length: " + bLength + " which is " + bufferSeconds + " seconds of audio";
document.getElementById("cTime").innerHTML = "Time: " + 0.0;



function updateTimeNodes(t){
    for (var i = 0; i < timeNodes.length; i++) {
        timeNodes[i].inputs[0].value = t;
    }

}


function load(buffer){
    let t;

    var cBuffer = buffer.getChannelData(0);
    for (var i = 0; i < bufferB.length; i++) {
        t = (i*bufferSeconds) / bLength;
        updateTimeNodes(t + counter);

        evaluateAllNodes();
       
        cBuffer[i] = outputNode.inputs[0].value.x;
t
        if(breakOutOfEverything == true){
            breakOutOfEverything = false;
            console.log("Uh oh");
            break;
        }
    }

    cBuffer = buffer.getChannelData(1);
    for (var i = 0; i < bufferB.length; i++) {
        t = (i*bufferSeconds) / bLength;
        
        updateTimeNodes(t + counter);
        evaluateAllNodes();
        
        cBuffer[i] = outputNode.inputs[0].value.y;
        
        if(breakOutOfEverything == true){
            breakOutOfEverything = false;
            console.log("Uh oh");
            break;
        }
    }
}



var counter = 0;

function runB(){
    var source = audioCtx.createBufferSource();
    source.buffer = bufferB;
    source.connect(audioCtx.destination);
    source.start(); // Start B

    counter += bufferSeconds;
    load(bufferA);

    source.onended = function(){
        runA();
    }
}

function runA(){
    var source = audioCtx.createBufferSource();
    source.buffer = bufferA;
    source.connect(audioCtx.destination);
    source.start(); // Start A

    counter += bufferSeconds;
    load(bufferB);

    source.onended = function(){
        runB();
    }
}

function startAudio(){
    load(bufferA);
    runA();
    startTimer();
}




var timerInterval;
var initialTime;

function updateTimer(){
    var cTime = new Date();
    var currentTime = cTime.getTime() - initialTime; 
   
    document.getElementById("cTime").innerHTML = "Time: " + (currentTime / 1000).toFixed(2);

}

// Starts the playback timer
function startTimer(){
    var cTime = new Date();
    initialTime = cTime.getTime();
    timerInterval = setInterval(updateTimer, 1);
}


function initialize(){
    //evaluateAllNodes();
    //evaluateAllNodes();
    //load(bufferA);
}

