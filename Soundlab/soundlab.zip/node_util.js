var mz = 1;

var svg = document.getElementById('svg');
svg.ns = svg.namespaceURI;


var selectedInput = null;
var selectedOutput = null;


var mouse = {x: 0, y: 0, down: false, dragging: false, selectedInput: null, selectedOutput: null};

document.body.onmousemove = function (e) {
    getMousePos(e);
    
    if(mouse.dragging){
        //mouse.selectedPath.nodeInputEl.style.top = (mouse.y - 300) + "px";
        //mouse.selectedPath.nodeInputEl.style.left = (mouse.x - 300) + "px";
        //console.log("Dragging");

        if(mouse.selectedInput){
            //mouse.selectedInput.updateSinglePath();
        }
    }
}


function getMousePos(e) {
	mouse.x = e.clientX;
    mouse.y = e.clientY;
}



document.body.onmouseup = document.body.onmouseout = function (e) {
    mouse.down = false;
    //mouse.dragging = false;
}




function rgbToHex(r, g, b) {
  return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
}


function getOffset(el){
    var rect = el.getBoundingClientRect();

    var position = {
        top: rect.top + window.pageYOffset,
        left: rect.left + window.pageXOffset
    };

    return position;
}