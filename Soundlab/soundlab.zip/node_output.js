
function NodeOutput(output){
    this.name = output.name;
    this.type = output.type;
    this.value = 0;

    this.owner = null;
    this.connectedInputs = [];

    this.nodeOutputEl = document.createElement('div');
    this.nodeOutputEl.classList.add('nodeOutput');
    this.nodeOutputEl.innerHTML = this.name;
}


NodeOutput.prototype.createPath = function(a, b){
    var diff = {
        x: b.x - a.x,
        y: b.y - a.y
    };
      
    var pathStr = 'M' + a.x + ',' + a.y + ' ';
    pathStr += 'C';
    pathStr += a.x + diff.x / 3 * 2 + ',' + a.y + ' ';
    pathStr += a.x + diff.x / 3 + ',' + b.y + ' ';
    pathStr += b.x + ',' + b.y;
      
    return pathStr;
};

NodeOutput.prototype.getOutputOffset = function(){
    var tmp = this.nodeOutputEl;
    var offset = getOffset(tmp);
    
    return {
        x: offset.left + tmp.offsetWidth / 2 + 35,
        y: offset.top + tmp.offsetHeight / 2
    };
};

NodeOutput.prototype.connect = function(input){
    if(this.type == input.type){

        // Set this inputs connected output
        input.connectedOutput = this;

        // Set the value of the input to the calue of the output
        input.value = this.value;

        // Add this input to the outputs connected inputs
        this.connectedInputs.push(input);

        // Input is dirty
        input.isDirty = true;

        // Hide the input box if there is one
        if(input.inputBox)
            input.inputBox.style.display = "none";

        // Create new path 
        var newPath = document.createElementNS(svg.ns, 'path');
        newPath.setAttributeNS(null, 'stroke', '#8e8e8e');
        newPath.setAttributeNS(null, 'stroke-width', '2');
        newPath.setAttributeNS(null, 'fill', 'none');
    
        var inPoint = input.getInputOffset();
        var outPoint = this.getOutputOffset();

        var svgPath = this.createPath(outPoint, inPoint);
        newPath.setAttributeNS(null, 'd', svgPath);
        svg.appendChild(newPath);

        // Set the inputs path to the new path
        input.path = newPath;


        console.log("Connected output '" + this.name + "' of node '" + this.owner.name + "' to input '" + input.name + "' of node '" + input.owner.name + "' ");
    }
    else{
        console.log("Input type does not match the output.");
    }
}