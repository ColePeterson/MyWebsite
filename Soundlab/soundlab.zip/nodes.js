


function Node(name, pos, inputList, outputList, specs, evaluateNode){
    var that = this;

    this.name = name;
    this.specs = specs;

    this.inputs = [];
    this.outputs = [];
    
    this.evaluate = evaluateNode;

    // Create base DOM element with title
    this.nodeParentEl = document.createElement('div');
    this.nodeParentEl.classList.add('nodeParentEl');
    this.nodeParentEl.innerHTML = name;

    // Create the node body DOM element
    this.nodeBody = document.createElement('div');
    this.nodeBody.classList.add('nodeBody');
    
    this.hoverInfoEl = document.createElement('div');
    this.hoverInfoEl.classList.add('hoverInfo');
    this.hoverInfoEl.style.display = "none";

    this.nodeParentEl.appendChild(this.hoverInfoEl);

    this.nodeParentEl.onmousemove = function(){
        //that.hoverInfoEl.style.display = "block";
        
        let infoStr = "Inputs: <br />";

        for(let i = 0; i < that.inputs.length; i++){
            let name = that.inputs[i].name;
            if(name == "") name = "In";
            
            
            infoStr += (name + " - " + that.inputs[i].value + "<br />");
        }

        infoStr += "Outputs: <br />";

        for(let i = 0; i < that.outputs.length; i++){
            let name = that.outputs[i].name;
            
            infoStr += (name + " - " + that.outputs[i].value + "<br />");
        }

        that.hoverInfoEl.innerHTML = infoStr;

    }
    this.nodeParentEl.onmouseleave = function(){
        //that.hoverInfoEl.style.display = "none";
    }

    for(var i = 0; i < outputList.length; i++){
        this.addOutput(outputList[i]);
    }

    for(var i = 0; i < inputList.length; i++){
        this.addInput(inputList[i]);
    }


    this.nodeParentEl.appendChild(this.nodeBody);

    this.nodeParentEl.onmousedown = function(){
        mz ++;
        that.nodeParentEl.style.zIndex = mz.toString();
    }

    // Initialize position
    this.moveTo({x: pos.x, y: pos.y});

    // Initialize jqueryui functions
    this.initNodeUi();
}




// Add new input to node
Node.prototype.addInput = function(input){
    var newInput = new NodeInput(input, this);
    newInput.owner = this;

    this.inputs.push(newInput);

    if(this.inputs.length == 1 && this.outputs.length == 1){
        this.outputs[0].nodeOutputEl.style.top = "0%";
    }
    else if(this.inputs.length == 2 && this.outputs.length == 1){
        this.outputs[0].nodeOutputEl.style.top = "25%";
    }

    this.nodeBody.appendChild(newInput.nodeInputEl);
}

// Add new output to node
Node.prototype.addOutput = function(input){
    var newOutput = new NodeOutput(input, this);
    newOutput.owner = this;

    this.outputs.push(newOutput);

    this.nodeBody.appendChild(newOutput.nodeOutputEl);
}

Node.prototype.updatePaths = function(){
    var nInputs = this.inputs.length;

    for(let i = 0; i < this.inputs.length; i++){
        if(this.inputs[i].connectedOutput != null && this.inputs[i].path != null){
            var inPoint = this.inputs[i].getInputOffset();
            var outPoint = this.inputs[i].connectedOutput.getOutputOffset();
            
            var svgPath = this.inputs[i].connectedOutput.createPath(outPoint, inPoint);
            this.inputs[i].path.setAttributeNS(null, 'd', svgPath);
        }
    }
    
    for(let i = 0; i < this.outputs.length; i++){
        for(let j = 0; j < this.outputs[i].connectedInputs.length; j++){

            var inPoint = this.outputs[i].connectedInputs[j].getInputOffset();
            var outPoint = this.outputs[i].getOutputOffset();
            
            var svgPath = this.outputs[i].createPath(outPoint, inPoint);
            this.outputs[i].connectedInputs[j].path.setAttributeNS(null, 'd', svgPath);
        }
            
    }
}


// Update node location
Node.prototype.moveTo = function(point){
    this.nodeParentEl.style.top = point.y + 'px';
    this.nodeParentEl.style.left = point.x + 'px';
    //this.updatePosition();
};

Node.prototype.initNodeUi = function(){
    var that = this;
    $(this.nodeParentEl).draggable({
        containment: 'window',
        cancel: '.nodeInput,.nodeOutput, .constant',
        drag: function(event, ui){
        that.updatePaths();
        }
    });
    
    //this.updatePosition();
    this.nodeParentEl.style.position = 'absolute';
    document.body.appendChild(this.nodeParentEl);
};
















function NodeInput(input){
    var that = this;

    this.name = input.name;
    this.type = input.type;


    if(input.type == "Number")
        this.value = 0;
    else if(input.type == "Vec2")
        this.value = {x: 0, y: 0};

   
   
    this.owner = null;
    this.isConnected = false;
    this.connectedOutput = null;
    this.path = null;

    this.isDirty = false;

    this.nodeInputEl = document.createElement('div');
    this.nodeInputEl.innerHTML = this.name;

    if(input.hasConnector)
        this.nodeInputEl.classList.add('nodeInput');
    else
        this.nodeInputEl.classList.add('constant');

    if(input.inputBox){
        this.inputBox = document.createElement('INPUT');
        this.inputBox.classList.add('nodeInputBox');
        this.inputBox.setAttribute("type", "text");
        this.inputBox.setAttribute("value", this.value);
        
        this.inputBox.addEventListener('change', function(){ 
            that.value = parseFloat(this.value);
            that.owner.evaluate(that.owner);
            that.isDirty = false;
        });

        this.nodeInputEl.appendChild(this.inputBox);
    }

    this.nodeInputEl.onmousedown = function(){
        mouse.dragging = true;
        selectedInput = that;

        if(that.connectedOutput != null)
            that.disconnect(that.connectedOutput);

        if(selectedOutput != null){
            selectedOutput.connect(selectedInput);
            selectedOutput = null;
            selectedInput = null;
        }
    }


}

NodeInput.prototype.getInputOffset = function(){
    var offset = getOffset(this.nodeInputEl);
    
    return {
        x: offset.left - 12,
        y: offset.top + this.nodeInputEl.offsetHeight / 2 - 2
    };

};


NodeInput.prototype.disconnect = function(output){
    if(this.connectedOutput != null){
        this.path.removeAttribute('d');
        this.path = null;
        this.connectedOutput = null;

        let index = output.connectedInputs.indexOf(this);
        output.connectedInputs.splice(index, 1);

        console.log("Disconnected input '" + this.name + "' of node '" + this.owner.name + "' from output '" + output.name + "' of node '" + output.owner.name + "' ");
    }
}

NodeInput.prototype.updateSinglePath = function(){

    var inPoint = {x:mouse.x, y:mouse.y};
    var outPoint = this.connectedOutput.getOutputOffset();

    var svgPath = this.connectedOutput.createPath(outPoint, inPoint);
    this.path.setAttributeNS(null, 'd', svgPath);

}



















function NodeOutput(output){
    var that = this;

    this.name = output.name;
    this.type = output.type;

    if(output.type == "Number")
        this.value = 0;
    else if(output.type == "Vec2")
        this.value = {x: 0, y: 0};

    this.owner = null;
    this.connectedInputs = [];

    this.nodeOutputEl = document.createElement('div');
    this.nodeOutputEl.classList.add('nodeOutput');
    this.nodeOutputEl.innerHTML = this.name;

    this.nodeOutputEl.onmousedown = function(){
       

        selectedOutput = that;
    }

}


NodeOutput.prototype.createPath = function(a, b){
    var diff = {
        x: b.x - a.x,
        y: b.y - a.y
    };
      
    var pathStr = 'M' + a.x + ',' + a.y + ' ';
    pathStr += 'C';
    pathStr += a.x + diff.x / 3 * 2 + ',' + a.y + ' ';
    pathStr += a.x + diff.x / 3 + ',' + b.y + ' ';
    pathStr += b.x + ',' + b.y;
      
    return pathStr;
};

NodeOutput.prototype.getOutputOffset = function(){
    var tmp = this.nodeOutputEl;
    var offset = getOffset(tmp);
    
    return {
        x: offset.left + tmp.offsetWidth / 2 + 35,
        y: offset.top + tmp.offsetHeight / 2
    };
};

NodeOutput.prototype.connect = function(input){
    if(this.type == input.type){

        // Set this inputs connected output
        input.connectedOutput = this;

        // Set the value of the input to the calue of the output
        input.value = this.value;

        // Add this input to the outputs connected inputs
        this.connectedInputs.push(input);

        // Input is dirty
        input.isDirty = true;

        // Hide the input box if there is one
        if(input.inputBox)
            input.inputBox.style.display = "none";

        // Create new path 
        var newPath = document.createElementNS(svg.ns, 'path');
        newPath.setAttributeNS(null, 'stroke', '#8e8e8e');
        newPath.setAttributeNS(null, 'stroke-width', '2');
        newPath.setAttributeNS(null, 'fill', 'none');
    
        var inPoint = input.getInputOffset();
        var outPoint = this.getOutputOffset();

        var svgPath = this.createPath(outPoint, inPoint);
        newPath.setAttributeNS(null, 'd', svgPath);
        svg.appendChild(newPath);

        // Set the inputs path to the new path
        input.path = newPath;


        console.log("Connected output '" + this.name + "' of node '" + this.owner.name + "' to input '" + input.name + "' of node '" + input.owner.name + "' ");
    }
    else{
        console.log("Input type does not match the output.");
    }
}
