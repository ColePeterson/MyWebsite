
function Node(name, pos, inputList, outputList, specs, evaluateNode){
    var that = this;

    this.name = name;
    this.specs = specs;

    this.inputs = [];
    this.outputs = [];
    
    this.evaluate = evaluateNode;

    // Create base DOM element with title
    this.nodeParentEl = document.createElement('div');
    this.nodeParentEl.classList.add('nodeParentEl');
    this.nodeParentEl.innerHTML = name;

    // Create the node body DOM element
    this.nodeBody = document.createElement('div');
    this.nodeBody.classList.add('nodeBody');
    
    this.hoverInfoEl = document.createElement('div');
    this.hoverInfoEl.classList.add('hoverInfo');
    this.hoverInfoEl.style.display = "none";

    this.nodeParentEl.appendChild(this.hoverInfoEl);

    this.nodeParentEl.onmousemove = function(){
        that.hoverInfoEl.style.display = "block";
        
        let infoStr = "Inputs: <br />";

        for(let i = 0; i < that.inputs.length; i++){
            let name = that.inputs[i].name;
            if(name == "") name = "In";
            
            infoStr += (name + " - " + that.inputs[i].value + "<br />");
        }

        infoStr += "Outputs: <br />";

        for(let i = 0; i < that.outputs.length; i++){
            let name = that.outputs[i].name;
            infoStr += (name + " - " + that.outputs[i].value + "<br />");
        }

        that.hoverInfoEl.innerHTML = infoStr;

    }
    this.nodeParentEl.onmouseleave = function(){
        that.hoverInfoEl.style.display = "none";
    }

    for(var i = 0; i < inputList.length; i++){
        this.addInput(inputList[i]);
    }

    for(var i = 0; i < outputList.length; i++){
        this.addOutput(outputList[i]);
    }

    this.nodeParentEl.appendChild(this.nodeBody);

    this.nodeParentEl.onmousedown = function(){
        mz ++;
        that.nodeParentEl.style.zIndex = mz.toString();
    }

    // Initialize position
    this.moveTo({x: pos.x, y: pos.y});

    // Initialize jqueryui functions
    this.initNodeUi();
}

Node.prototype.checkIfReady = function(){
    for(var i = 0; i < this.inputs.length; i++){
        if(this.inputs[i].isDirty)
            return false;
    }
    return true;
}


// Add new input to node
Node.prototype.addInput = function(input){
    var newInput = new NodeInput(input, this);
    newInput.owner = this;

    this.inputs.push(newInput);
    this.nodeBody.appendChild(newInput.nodeInputEl);
}

// Add new output to node
Node.prototype.addOutput = function(input){
    var newOutput = new NodeOutput(input, this);
    newOutput.owner = this;

    this.outputs.push(newOutput);
    this.nodeBody.appendChild(newOutput.nodeOutputEl);
}

Node.prototype.updatePaths = function(){
    var nInputs = this.inputs.length;

    for(let i = 0; i < this.inputs.length; i++){
        if(this.inputs[i].connectedOutput != null && this.inputs[i].path != null){
            var inPoint = this.inputs[i].getInputOffset();
            var outPoint = this.inputs[i].connectedOutput.getOutputOffset();
            
            var svgPath = this.inputs[i].connectedOutput.createPath(outPoint, inPoint);
            this.inputs[i].path.setAttributeNS(null, 'd', svgPath);
        }
    }
    
    for(let i = 0; i < this.outputs.length; i++){
        for(let j = 0; j < this.outputs[i].connectedInputs.length; j++){

            var inPoint = this.outputs[i].connectedInputs[j].getInputOffset();
            var outPoint = this.outputs[i].getOutputOffset();
            
            var svgPath = this.outputs[i].createPath(outPoint, inPoint);
            this.outputs[i].connectedInputs[j].path.setAttributeNS(null, 'd', svgPath);
        }
            
    }
}


// Update node location
Node.prototype.moveTo = function(point){
    this.nodeParentEl.style.top = point.y + 'px';
    this.nodeParentEl.style.left = point.x + 'px';
    //this.updatePosition();
};

Node.prototype.initNodeUi = function(){
    var that = this;
    $(this.nodeParentEl).draggable({
        containment: 'window',
        cancel: '.nodeInput,.nodeOutput, .constant',
        drag: function(event, ui){
        that.updatePaths();
        }
    });
    
    //this.updatePosition();
    this.nodeParentEl.style.position = 'absolute';
    document.body.appendChild(this.nodeParentEl);
};
