
function NodeInput(input){
    this.name = input.name;
    this.type = input.type;

    this.value = 0;
   

    this.owner = null;
    this.isConnected = false;
    this.connectedOutput = null;
    this.path = null;

    this.isDirty = false;

    this.nodeInputEl = document.createElement('div');
    this.nodeInputEl.innerHTML = this.name;

    if(input.hasConnector)
        this.nodeInputEl.classList.add('nodeInput');
    else
        this.nodeInputEl.classList.add('constant');

    if(input.inputBox){
        this.inputBox = document.createElement('INPUT');
        this.inputBox.classList.add('nodeInputBox');
        this.inputBox.setAttribute("type", "text");
        this.inputBox.setAttribute("value", this.value);
        
        this.inputBox.addEventListener('change', function(){ 
            that.value = parseFloat(this.value);
            that.owner.evaluate(that.owner);
            that.isDirty = false;
        });

        this.nodeInputEl.appendChild(this.inputBox);
    }

    var that = this;
    this.nodeInputEl.onmousedown = function(){
        mouse.selectedInput = that;
        mouse.dragging = true;
    }
}

NodeInput.prototype.getInputOffset = function(){
    var offset = getOffset(this.nodeInputEl);
    
    return {
        x: offset.left - 12,
        y: offset.top + this.nodeInputEl.offsetHeight / 2 - 2
    };

};


NodeInput.prototype.disconnect = function(output){
    if(this.connectedOutput != null){
        this.path.removeAttribute('d');
        this.path = null;
        this.connectedOutput = null;

        let index = output.connectedInputs.indexOf(this);
        output.connectedInputs.splice(index, 1);

        console.log("Disconnected input '" + this.name + "' of node '" + this.owner.name + "' from output '" + output.name + "' of node '" + output.owner.name + "' ");
    }
}

NodeInput.prototype.updateSinglePath = function(){

    var inPoint = {x:mouse.x, y:mouse.y};
    var outPoint = this.connectedOutput.getOutputOffset();

    var svgPath = this.connectedOutput.createPath(outPoint, inPoint);
    this.path.setAttributeNS(null, 'd', svgPath);

}
